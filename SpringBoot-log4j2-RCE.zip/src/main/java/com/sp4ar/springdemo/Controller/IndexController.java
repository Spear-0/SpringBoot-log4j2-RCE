package com.sp4ar.springdemo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Controller
@ResponseBody
public class IndexController {
    private static final Logger log = LogManager.getLogger(IndexController.class);

    @RequestMapping(method = RequestMethod.GET, value = "/")
    public String Index(@RequestParam("id") String id){
        log.error(id);
        return id;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/api")
    public String Index(@RequestParam("name") String name, @RequestParam("password") String password){
        log.error(name);
        log.info(password);
        return name+password;
    }

}
